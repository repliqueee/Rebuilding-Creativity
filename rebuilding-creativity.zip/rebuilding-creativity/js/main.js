/* ============================================================
   Rebuilding Creativity — app logic
   Рендерит хедер, меню, ленту и страницу интервью на основе
   данных из js/data.js. Правь контент там, а не здесь.
   ============================================================ */

const { CATEGORIES, TOP_TABS, INTERVIEWS, ABOUT } = window.RC_DATA;

const ICON_MENU = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`;
const ICON_CLOSE = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></svg>`;
const ICON_CHEV = `<svg class="chev" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`;

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

/* ---------- Header ------------------------------------------ */
function renderHeader({ titleHtml, mountId = "site-header" }) {
  const el = document.getElementById(mountId);
  if (!el) return;
  el.innerHTML = `
    <a class="site-header__brand" href="index.html">
      <img class="site-logo" src="assets/images/logo.png" alt="Rebuilding Creativity" onerror="this.style.display='none'">
      <span class="site-title">${titleHtml}</span>
    </a>
    <button class="menu-btn" id="menuToggle" aria-label="Открыть меню">${ICON_MENU}</button>
  `;
  document.getElementById("menuToggle").addEventListener("click", openMenu);
}

/* ---------- Menu overlay -------------------------------------- */
function renderMenuOverlay(activeSlugOrCategory) {
  const overlayHtml = `
    <div class="menu-overlay" id="menuOverlay">
      <div class="site-header container" style="padding-left:0;padding-right:0;">
        <a class="site-header__brand" href="index.html">
          <img class="site-logo" src="assets/images/logo.png" alt="" onerror="this.style.display='none'">
          <span class="site-title" style="font-style:normal;font-family:var(--font-body);font-weight:600;font-size:16px;">Меню</span>
        </a>
        <button class="menu-btn is-close" id="menuClose" aria-label="Закрыть меню">${ICON_CLOSE}</button>
      </div>
      <nav class="menu-tabs">
        ${TOP_TABS.map(t => `<a href="${t.href || 'index.html'}" data-tab="${t.id}">${t.label}</a>`).join("")}
      </nav>
      <div class="menu-categories">
        ${CATEGORIES.map(cat => renderMenuCategory(cat, activeSlugOrCategory)).join("")}
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML("beforeend", overlayHtml);
  document.getElementById("menuClose").addEventListener("click", closeMenu);

  document.querySelectorAll(".menu-category__head").forEach((btn) => {
    btn.addEventListener("click", () => {
      btn.closest(".menu-category").classList.toggle("is-open");
    });
  });
}

function renderMenuCategory(cat, activeSlug) {
  const items = INTERVIEWS.filter((i) => i.category === cat.id);
  const isOpenByDefault = items.some((i) => i.slug === activeSlug);
  return `
    <div class="menu-category ${isOpenByDefault ? "is-open" : ""}">
      <button class="menu-category__head" type="button">
        <span>${cat.label}</span>
        ${ICON_CHEV}
      </button>
      <div class="menu-category__body">
        ${items.length
          ? items.map((i) => `<a class="menu-entry ${i.slug === activeSlug ? "is-active" : ""}" href="interview.html?slug=${i.slug}">${escapeHtml(i.title)}</a>`).join("")
          : `<span class="menu-entry" style="opacity:.5;">Пока пусто</span>`}
      </div>
    </div>
  `;
}

function openMenu() {
  document.getElementById("menuOverlay")?.classList.add("is-open");
  document.body.style.overflow = "hidden";
}
function closeMenu() {
  document.getElementById("menuOverlay")?.classList.remove("is-open");
  document.body.style.overflow = "";
}

/* ---------- Feed card ------------------------------------------ */
function renderCard(item) {
  const mediaHtml = item.hero?.type === "color"
    ? `
      <div class="hero-block" style="background:${item.hero.color};">
        <div class="hero-block__lines">
          ${item.hero.lines.map((line, idx) =>
            `<div class="${idx === item.hero.lines.length - 1 && item.hero.lastLineStyle === "italic-underline" ? "line--italic" : ""}">${escapeHtml(line)}</div>`
          ).join("")}
        </div>
        ${item.issueNumber ? `
          <div class="hero-block__meta">
            <div class="hero-block__issue">Выпуск ${item.issueNumber}</div>
            <div class="hero-block__coauthors">совместно с ${item.coauthors.map(c => `<a href="${c.url}">${escapeHtml(c.name)}</a>`).join(", ")}</div>
          </div>` : ""}
      </div>`
    : `
      <div class="card__media">
        <img src="${item.hero.image}" alt="${escapeHtml(item.title)}" onerror="this.parentElement.innerHTML='<div class=\\'media-placeholder\\'>Добавь изображение:<br>${item.hero.image}</div>'">
      </div>`;

  return `
    <a class="card ${item.hero?.type === "color" ? "card--hero" : ""}" href="interview.html?slug=${item.slug}">
      ${mediaHtml}
      <div class="card__body">
        <h2 class="card__title">${escapeHtml(item.title)}</h2>
        <p class="card__excerpt">${escapeHtml(item.excerpt)}</p>
        <div class="tag-row">
          ${item.tags.map(t => `<span class="tag">${escapeHtml(t)}</span>`).join("")}
        </div>
      </div>
    </a>
  `;
}

/* ---------- Page: index (feed) ------------------------------ */
function initFeedPage() {
  renderHeader({ titleHtml: "Новые Выпуски" });
  renderMenuOverlay(null);
  const feedEl = document.getElementById("feed");
  feedEl.innerHTML = INTERVIEWS.map(renderCard).join("");
}

/* ---------- Page: interview ---------------------------------- */
function initInterviewPage() {
  const params = new URLSearchParams(window.location.search);
  const slug = params.get("slug");
  const item = INTERVIEWS.find((i) => i.slug === slug) || INTERVIEWS[0];
  const category = CATEGORIES.find((c) => c.id === item.category);

  renderHeader({
    titleHtml: `Разговоры<span class="crumb-sep">·</span><span class="crumb-active">${category ? category.label : ""}</span>`,
  });
  renderMenuOverlay(item.slug);

  const coverHtml = item.hero.type === "color"
    ? `<div class="hero-block" style="border-radius:var(--radius-lg);aspect-ratio:3/4;background:${item.hero.color};">
         <div class="hero-block__lines">
           ${item.hero.lines.map((line, idx) =>
             `<div class="${idx === item.hero.lines.length - 1 && item.hero.lastLineStyle === "italic-underline" ? "line--italic" : ""}">${escapeHtml(line)}</div>`
           ).join("")}
         </div>
         ${item.issueNumber ? `
          <div class="hero-block__meta">
            <div class="hero-block__issue">Выпуск ${item.issueNumber}</div>
            <div class="hero-block__coauthors">совместно с ${item.coauthors.map(c => `<a href="${c.url}">${escapeHtml(c.name)}</a>`).join(", ")}</div>
          </div>` : ""}
       </div>`
    : `<img src="${item.hero.image}" alt="${escapeHtml(item.title)}" onerror="this.parentElement.innerHTML='<div class=\\'media-placeholder\\' style=\\'aspect-ratio:4/3\\'>Добавь изображение:<br>${item.hero.image}</div>'">`;

  const bodyHtml = item.content.map((block) => {
    if (block.type === "paragraph") {
      return `<p>${escapeHtml(block.text)}</p>`;
    }
    return `<p><span class="qa-speaker">${escapeHtml(block.speaker)}:</span>${escapeHtml(block.text)}</p>`;
  }).join("");

  document.getElementById("article").innerHTML = `
    <div class="article__cover">${coverHtml}</div>
    <h1 class="article__title">${escapeHtml(item.title)}</h1>
    <p class="article__excerpt">${escapeHtml(item.excerpt)}</p>
    <div class="article__body">${bodyHtml}</div>
  `;

  document.title = `${item.title} — Rebuilding Creativity`;
}

/* ---------- Page: about --------------------------------------- */
function initAboutPage() {
  renderHeader({ titleHtml: "О Проекте" });
  renderMenuOverlay(null);
  document.getElementById("about").innerHTML = ABOUT.sections.map((s) => `
    <h2>${escapeHtml(s.heading)}</h2>
    ${s.paragraphs.map(p => `<p>${escapeHtml(p)}</p>`).join("")}
  `).join("");
}
